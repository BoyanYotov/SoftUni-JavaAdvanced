package DefiningClasses_06.CarConstructor_02;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        Car car = new Car();

        for (int i = 1; i <= n ; i++) {
            String[] input = scanner.nextLine().split("\\s+");

            if (input.length == 1) {
                String brand = input[0];
                car.setBrand(brand);
                car.setModel("unknown");
                car.setHorsePowers(-1);
            } else {
                String brand = input[0];
                String model = input[1];
                int horsePower = Integer.parseInt(input[2]);
                car.setBrand(brand);
                car.setModel(model);
                car.setHorsePowers(horsePower);
            }

            System.out.println(car.carInfo());
        }

    }

}
